package com.example.maligiganci

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MakePlayer : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_make_player)
    }
}